<?php
declare(strict_types=1);
require __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

function db(): PDO {
    static $pdo = null;
    if (!$pdo) {
        $pdo = new PDO(DB_DSN, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}
function out($data, int $code = 200): never { http_response_code($code); echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; }
function fail(string $msg, int $code = 400): never { out(['error' => $msg], $code); }
function body(): array { $j = json_decode(file_get_contents('php://input') ?: '', true); return is_array($j) ? $j : $_POST; }
function str(array $a, string $k, int $max = 255): string { return mb_substr(trim((string)($a[$k] ?? '')), 0, $max); }
function require_admin(): void { if (empty($_SESSION['admin_id'])) fail('Administrator login required.', 401); }
function luhn(string $n): bool {
    $t = 0; $f = false;
    for ($i = strlen($n) - 1; $i >= 0; $i--) { $d = (int)$n[$i]; if ($f) { $d *= 2; if ($d > 9) $d -= 9; } $t += $d; $f = !$f; }
    return $t % 10 === 0;
}
function date_taken(int $hall, string $date): bool {
    $s = db()->prepare("SELECT COUNT(*) FROM booking WHERE hall_id=? AND event_date=? AND status='Confirmed'");
    $s->execute([$hall, $date]);
    return (int)$s->fetchColumn() > 0;
}
set_exception_handler(function (Throwable $e) { error_log((string)$e); fail('Server error. Please try again.', 500); });

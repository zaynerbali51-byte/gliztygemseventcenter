# Gliztygems Event Center: Back End (PHP 8 + MySQL)

## Setup (XAMPP / WAMP / any PHP host)
1. Import `gliztygems_database.sql` (phpMyAdmin > Import). It creates `gliztygems_db`.
2. Copy this folder into `htdocs/gliztygems-backend`.
3. Edit `config.php` if your MySQL user or password differs.
4. Test: open `http://localhost/gliztygems-backend/api/halls.php` (you should see the three halls as JSON).

## Endpoints (JSON)
| Endpoint | Method | Who | Purpose |
|---|---|---|---|
| `api/halls.php` | GET | public | Hall list. `?guests=N` runs Smart Hall Match |
| `api/halls.php` | PUT | admin | Update hall name, capacity, price, status, description |
| `api/availability.php?hall_id=1&month=2026-12` | GET | public | Confirmed (blocked) dates |
| `api/bookings.php` | POST | public | Create a Pending booking (full validation) |
| `api/bookings.php?code=GG-XXXXXX` | GET | public | Verify a booking and see progress |
| `api/bookings.php?status=&q=&date=` | GET | admin | Search and filter all bookings |
| `api/payment.php` | POST | public | Simulated payment; approves or declines |
| `api/tasks.php` | GET/POST/PUT/DELETE | code holder | Preparation tasks and progress % |
| `api/admin.php?action=login` | POST | admin | Login (`username`, `password`) |
| `api/admin.php?action=stats\|payments\|customers\|logout` | GET | admin | Dashboard data |

## Business rules enforced on the server
- Required fields, email, phone, date and guest limits are validated.
- A booking is rejected if the hall already has a confirmed booking on that date, and the database also blocks it (`uq_confirmed_slot`).
- Only an approved simulated payment makes a booking Confirmed and creates the verification code.
- Simulation: valid cards are approved, cards ending in `0002` are declined.
- Card numbers and CVVs are validated but never stored; only the last 4 digits are kept.
- Tasks are available only to Confirmed bookings, using the verification code.
- Progress % = completed tasks / total tasks x 100 (3 of 8 = 37.5).
- All SQL uses prepared statements; admin passwords use `password_verify`.

## Demo login
`admin` / `admin123`. Change it in the `admin` table before any real use.

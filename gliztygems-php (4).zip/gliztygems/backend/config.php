<?php
// Database settings: edit for your server (XAMPP defaults shown).
const DB_DSN  = 'mysql:host=localhost;dbname=gliztygemseventcenter;charset=utf8mb4';
const DB_USER = 'root';
const DB_PASS = '';
